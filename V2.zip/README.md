# VB6-RVO-Alternative
RVO Reciprocal Velocity Obstacles collision avoidance Alternative - Very Simpler and efficent

requires vbRichClient for render
https://vbrichclient.com/#/en/About/
